require("firethefox.remap")
require("firethefox.set")

vim.keymap.set("n", "Q", "<nop>")
vim.api.nvim_set_option("clipboard","unnamedplus") 
